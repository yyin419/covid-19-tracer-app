import 'react-native-gesture-handler';
import React, { useState } from 'react';
import { Text, View } from 'react-native';


import MealsNavigator from './navigation/MealsNavigator';



export default function App() {
 

  return <MealsNavigator />;

}
