import React, { Component, Fragment } from 'react';
import QRCodeScanner from 'react-native-qrcode-scanner';
import {
    TouchableOpacity,
    Text,
    StatusBar,
    Linking,
    View,
    StyleSheet
} from 'react-native';


class ScanScreen extends Component {
    constructor(props) {
        super(props);
        this.state = {
            scan: false,
            ScanResult: false,
            result: null,
            data:''
        };
    }

    componentDidMount() {
      var that = this;
      var date = new Date().getDate(); //Current Date
      var month = new Date().getMonth() + 1; //Current Month
      var year = new Date().getFullYear(); //Current Year
      var hours = new Date().getHours(); //Current Hours
      var min = new Date().getMinutes(); //Current Minutes
      var sec = new Date().getSeconds(); //Current Seconds
      that.setState({
        //Setting the value of the date time
        date:
          date + '/' + month + '/' + year + ' ' + hours + ':' + min + ':' + sec,
      });
    }
    onSuccess = (e) => {
        const check = e.data.substring(0, 4);
        console.log('scanned data' + check);
        this.setState({
            result: e,
            scan: false,
            ScanResult: true
        })
        if (check === 'http') {
            Linking
                .openURL(e.data)
                .catch(err => console.error('An error occured', err));


        } else {
            this.setState({
                result: e,
                scan: false,
                ScanResult: true
            })
        }

    }

    activeQR = () => {
        this.setState({
            scan: true
        })
    }
    scanAgain = () => {
        this.setState({
            scan: true,
            ScanResult: false
        })
    }
    render() {
        const { scan, ScanResult, result } = this.state
        
        return (
            <View>
                <Fragment>
                    <StatusBar barStyle="dark-content" />
                    
                    {!scan && !ScanResult &&
                        <View >
    
                            <Text>Scan to record location!</Text>
                            <TouchableOpacity onPress={this.activeQR}>
                                <Text  style={styles.buttonText}>Click to Scan !</Text>
                            </TouchableOpacity>

                        </View>
                    }

                    {ScanResult &&
                        <Fragment>
                            <Text style={{ fontSize: 30, }}>Result!</Text>
                            <View>
                                <Text style={{ fontSize: 15, }}>Type: {result.type}</Text>
                                <Text style={{ fontSize: 15, }}>Result: {result.data}</Text>
                                <Text style={{ fontSize: 15, }} numberOfLines={1}>RawData: {result.rawData}</Text>
                                <Text style={{ fontSize: 15, }}>Location Record Time: {this.state.date}</Text> 
                              
                                <TouchableOpacity onPress={this.scanAgain} >
                                    <Text style={styles.buttonText}>Click to Scan again!</Text>
                                </TouchableOpacity>
                                
                                <TouchableOpacity onPress={() => {this.props.navigation.navigate({routeName: 'History'});}} >
                                    <Text style={styles.buttonText}>View record history</Text>
                                </TouchableOpacity>
                            </View>
                        </Fragment>
                    }


                    {scan &&
                        <QRCodeScanner
                            reactivate={true}
                            showMarker={true}
                            ref={(node) => { this.scanner = node }}
                            onRead={this.onSuccess}
                            
                            bottomContent={
                                <View>
                                    <TouchableOpacity style={styles.buttonTouchable} onPress={() => this.scanner.reactivate()}>
                                        <Text style={styles.buttonText}>OK. Got it!</Text>
                                    </TouchableOpacity>

                                    <TouchableOpacity style={styles.buttonTouchable} onPress={() => this.setState({ scan: false })}>
                                        <Text style={styles.buttonText}>Stop Scan</Text>
                                    </TouchableOpacity>
                                </View>

                            }
                        />
                    }
                </Fragment>
            </View>

        );
    }
}

const styles = StyleSheet.create({
  centerText: {
    flex: 1,
    fontSize: 18,
    padding: 32,
    color: '#777'
  },
  textBold: {
    fontWeight: '500',
    color: '#000'
  },
  buttonText: {
    marginTop: 50,
    fontSize: 21,
    color: 'rgb(0,122,255)'
  },
  buttonTouchable: {
    padding: 16
  }
});

export default ScanScreen;